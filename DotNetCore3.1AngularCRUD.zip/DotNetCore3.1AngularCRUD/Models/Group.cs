﻿using System;
using System.Collections.Generic;

namespace DotNetCore3._1AngularCRUD.Models
{
    public partial class Group
    {
        public string Name { get; set; }
        public string Id { get; set; }
    }
}
