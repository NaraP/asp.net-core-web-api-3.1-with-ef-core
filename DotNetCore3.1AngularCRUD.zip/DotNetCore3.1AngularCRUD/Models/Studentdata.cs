﻿using System;
using System.Collections.Generic;

namespace DotNetCore3._1AngularCRUD.Models
{
    public partial class Studentdata
    {
        public int Id { get; set; }
        public string Studentname { get; set; }
        public string Fname { get; set; }
        public string Mname { get; set; }
        public string Contactno { get; set; }
    }
}
