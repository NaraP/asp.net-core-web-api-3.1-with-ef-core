﻿using System;
using System.Collections.Generic;

namespace DotNetCore3._1AngularCRUD.Models
{
    public partial class Customer
    {
        public string Name { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
        public string Address { get; set; }
        public int Id { get; set; }
    }
}
