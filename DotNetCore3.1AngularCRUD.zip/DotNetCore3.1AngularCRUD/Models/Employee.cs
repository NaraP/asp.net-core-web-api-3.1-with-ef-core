﻿using System;
using System.Collections.Generic;

namespace DotNetCore3._1AngularCRUD.Models
{
    public partial class Employee
    {
        public int Employeeid { get; set; }
        public string Name { get; set; }
        public string City { get; set; }
        public string Department { get; set; }
        public string Gender { get; set; }
    }
}
