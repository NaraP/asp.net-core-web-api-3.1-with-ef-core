﻿using DotNetCore3._1AngularCRUD.Models;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace DotNetCore3._1AngularCRUD.Repository
{
    public class EmployeRepository : IEmployeRepository
    {
        private readonly SampleDbContext _sampleDbContext;

        public EmployeRepository(SampleDbContext employeRepository)
        {
            _sampleDbContext = employeRepository;
        }

        public IEnumerable<Employee> GetAllEmployees()
        {
            try
            {
                return _sampleDbContext.Employee.ToList();
            }
            catch
            {
                throw;
            }
        }

        //To Add new employee record   
        public int AddEmployee(Employee employee)
        {
            try
            {
                _sampleDbContext.Employee.Add(employee);
                _sampleDbContext.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }

        //To Update the records of a particluar employee  
        public int UpdateEmployee(Employee employee)
        {
            try
            {
                _sampleDbContext.Entry(employee).State = EntityState.Modified;
                _sampleDbContext.SaveChanges();

                return 1;
            }
            catch
            {
                throw;
            }
        }

        //Get the details of a particular employee  
        public Employee GetEmployeeData(int id)
        {
            try
            {
                Employee employee = _sampleDbContext.Employee.Find(id);
                return employee;
            }
            catch
            {
                throw;
            }
        }

        //To Delete the record of a particular employee  
        public int DeleteEmployee(int id)
        {
            try
            {
                Employee emp = _sampleDbContext.Employee.Find(id);
                _sampleDbContext.Employee.Remove(emp);
                _sampleDbContext.SaveChanges();
                return 1;
            }
            catch
            {
                throw;
            }
        }

        //To Get the list of Cities  
        //public List<Cities> GetCities()
        //{
        //    List<Cities> lstCity = new List<Cities>()
        //    {
        //        new Cities{Id=1,Name="New Delhi"},
        //        new Cities{Id=2,Name="New Delhi"},
        //        new Cities{Id=3,Name="Hyderabad"},
        //        new Cities{Id=4,Name="Chennai"},
        //        new Cities{Id=5,Name="Bengaluru"}
        //    };


        //    // lstCity = (from CityList in _sampleDbContext.Cities select CityList).ToList();

        //    return lstCity;
        //}
    }
}
