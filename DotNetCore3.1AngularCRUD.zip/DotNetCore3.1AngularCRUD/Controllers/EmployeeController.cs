﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetCore3._1AngularCRUD.Models;
using DotNetCore3._1AngularCRUD.Repository;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCore3._1AngularCRUD.Controllers
{
    //[Route("api/[controller]")]
    //[ApiController]
    public class EmployeeController : ControllerBase
    {
        public readonly IEmployeRepository _objemployee;

        public EmployeeController(IEmployeRepository objemployee)
        {
            _objemployee = objemployee;
        }

        [HttpGet]
        [Route("api/Employee/Index")]
        public IEnumerable<Employee> Index()
        {
            return _objemployee.GetAllEmployees();
        }

        [HttpPost]
        [Route("api/Employee/Create")]
        public int Create([FromBody] Employee employee)
        {
            return _objemployee.AddEmployee(employee);
        }

        [HttpGet]
        [Route("api/Employee/Details/{id}")]
        public Employee Details(int id)
        {
            return _objemployee.GetEmployeeData(id);
        }

        [HttpPut]
        [Route("api/Employee/Edit")]
        public int Edit([FromBody] Employee employee)
        {
            return _objemployee.UpdateEmployee(employee);
        }

        [HttpDelete]
        [Route("api/Employee/Delete/{id}")]
        public int Delete(int id)
        {
            return _objemployee.DeleteEmployee(id);
        }

        //[HttpGet]
        //[Route("api/Employee/GetCityList")]
        //public IEnumerable<Cities> Details()
        //{
        //    return _objemployee.GetCities();
        //}
    }
}