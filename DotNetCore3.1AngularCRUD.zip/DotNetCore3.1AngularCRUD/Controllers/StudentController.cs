﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using DotNetCore3._1AngularCRUD.Dto;
using DotNetCore3._1AngularCRUD.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DotNetCore3._1AngularCRUD.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        SampleDbContext wmsEN = new SampleDbContext();

        [Route("StudentInsert")]
        [HttpPost]
        public IActionResult StudentInsert(StudentVM objVM)
        {
            try
            {
                if (objVM.Id == 0)
                {
                    var objlm = new Studentdata();
                    objlm.Id = 1;
                    objlm.Studentname = objVM.StudentName;
                    objlm.Fname = objVM.FName;
                    objlm.Mname = objVM.MName;
                    objlm.Contactno = objVM.ContactNo;
                    wmsEN.Studentdata.Add(objlm);
                    wmsEN.SaveChanges();

                    return Ok(200);
                }
                else
                {
                    var objlm = wmsEN.Studentdata.Where(s => s.Id == objVM.Id).ToList<Studentdata>().FirstOrDefault();

                    if (objlm.Id > 0)
                    {
                        objlm.Studentname = objVM.StudentName;
                        objlm.Fname = objVM.FName;
                        objlm.Mname = objVM.MName;
                        objlm.Contactno = objVM.ContactNo;
                        wmsEN.SaveChanges();
                    }
                }
            }
            catch (Exception ex)
            {
            }
            return Ok(200);

        }
        [Route("GetStudentData")]
        [HttpGet]
        public IActionResult GetStudentData()
        {
            var obj = from u in wmsEN.Studentdata
                      select u;
            return Ok(obj);
        }
        [Route("GetStudentById")]
        [HttpGet]
        public object GetStudentById(int Id)
        {
            return wmsEN.Studentdata.Where(s => s.Id == Id).ToList<Studentdata>().FirstOrDefault();
        }
        [Route("DeleteStudent")]
        [HttpGet]
        public object DeleteStudent(int Id)
        {
            try
            {
                var objlm = wmsEN.Studentdata.Where(s => s.Id == Id).ToList<Studentdata>().FirstOrDefault();
                wmsEN.Studentdata.Remove(objlm);
                wmsEN.SaveChanges();
                return new ResultVM
                { Status = "Success", Message = "SuccessFully Delete." };
            }
            catch (Exception ex)
            {
                return new ResultVM
                { Status = "Error", Message = ex.Message.ToString() };
            }
        }
    }
}